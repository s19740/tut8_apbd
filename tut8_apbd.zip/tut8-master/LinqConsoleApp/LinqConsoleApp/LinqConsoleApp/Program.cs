﻿using System;

namespace LinqConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            var d = new LinqSamples();
            d.Task7();
            d.Task8();
            d.Task9();
            d.Task11();
            d.Task12();
        }
    }
}
